package com.sermonassistant;

public final class IntegrationHarness {
    public static void main(String[] args) throws Exception {
        final Object gate=new Object();
        ProjectorClient c=new ProjectorClient(new ProjectorClient.Listener(){
            public void onStatus(String message, boolean connected){System.out.println("STATUS|"+connected+"|"+message);}
        });
        c.connect("127.0.0.1",19077);
        if(!c.send("CAPTION",WireProtocol.fields("text","Live caption test")))throw new RuntimeException("caption send failed");
        if(!c.send("SCRIPTURE",WireProtocol.fields("ref","John 3:16","version","NIV","text","For God so loved the world")))throw new RuntimeException("scripture send failed");
        if(!c.send("PRAYER",WireProtocol.fields("text","Father, give us wisdom")))throw new RuntimeException("prayer send failed");
        if(!c.send("SEGMENT",WireProtocol.fields("name","OFFERING","title","OFFERING","body","Give with joy")))throw new RuntimeException("segment send failed");
        if(!c.send("MEDIA",WireProtocol.fields("style","ANNOUNCEMENTS","title","ANNOUNCEMENT","body","Sunday service begins at 8 AM")))throw new RuntimeException("media send failed");
        if(!c.send("CLEAR",null))throw new RuntimeException("clear send failed");
        Thread.sleep(700);
        c.close();
        System.out.println("ANDROID_CLIENT_E2E_OK");
    }
}
