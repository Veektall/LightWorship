package com.sermonassistant;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.LinkedHashMap;
import java.util.Map;

public final class WireProtocol {
    private WireProtocol() {}

    public static String encode(String value) {
        if (value == null) return "";
        try {
            return URLEncoder.encode(value, "UTF-8").replace("+", "%20");
        } catch (UnsupportedEncodingException e) {
            return value;
        }
    }

    public static String decode(String value) {
        if (value == null) return "";
        try {
            return URLDecoder.decode(value, "UTF-8");
        } catch (Exception e) {
            return value;
        }
    }

    public static String build(String command, Map<String, String> fields) {
        StringBuilder b = new StringBuilder(command == null ? "" : command.toUpperCase());
        if (fields != null) {
            for (Map.Entry<String, String> e : fields.entrySet()) {
                b.append('\t').append(e.getKey()).append('=').append(encode(e.getValue()));
            }
        }
        return b.toString();
    }

    public static Map<String, String> fields(String... pairs) {
        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
        if (pairs != null) {
            for (int i = 0; i + 1 < pairs.length; i += 2) map.put(pairs[i], pairs[i + 1]);
        }
        return map;
    }
}
