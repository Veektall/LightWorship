package com.sermonassistant;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Map;

public final class ProjectorClient {
    public interface Listener { void onStatus(String message, boolean connected); }
    private volatile String host;
    private volatile int port = 9077;
    private Socket socket;
    private BufferedWriter writer;
    private final Listener listener;

    public ProjectorClient(Listener listener){this.listener=listener;}
    public String getHost(){return host;}

    public void discoverAndConnect() {
        new Thread(new Runnable(){ public void run(){
            DatagramSocket ds=null;
            try {
                ds=new DatagramSocket(); ds.setBroadcast(true); ds.setSoTimeout(1800);
                byte[] q="SERMON_ASSISTANT_DISCOVER_V1".getBytes("UTF-8");
                ds.send(new DatagramPacket(q,q.length,InetAddress.getByName("255.255.255.255"),9076));
                byte[] buf=new byte[512]; DatagramPacket p=new DatagramPacket(buf,buf.length); ds.receive(p);
                String r=new String(p.getData(),0,p.getLength(),"UTF-8");
                if (!r.startsWith("SERMON_ASSISTANT_COMPANION_V1")) throw new Exception("Unexpected discovery response");
                connect(p.getAddress().getHostAddress(),9077);
            } catch(Exception e){ notifyStatus("Discovery failed — enter PC IP manually",false); }
            finally { if(ds!=null) ds.close(); }
        }},"projector-discovery").start();
    }

    public synchronized void connect(final String ip,int p) throws Exception {
        close();
        Socket s=new Socket(); s.connect(new InetSocketAddress(ip,p),1800); s.setTcpNoDelay(true); s.setKeepAlive(true);
        socket=s; writer=new BufferedWriter(new OutputStreamWriter(s.getOutputStream(),"UTF-8")); host=ip; port=p;
        send("HELLO",WireProtocol.fields("device","Android Sermon Assistant","version","1.0.0"));
        final Socket drainSocket=s;
        new Thread(new Runnable(){ public void run(){ try { BufferedReader r=new BufferedReader(new InputStreamReader(drainSocket.getInputStream(),"UTF-8")); while(!drainSocket.isClosed() && r.readLine()!=null){} } catch(Exception ignored){} } },"projector-ack-drain").start();
        notifyStatus("Connected to projector: "+ip+":"+p,true);
    }

    public void connectAsync(final String ip) {
        new Thread(new Runnable(){public void run(){try{connect(ip,9077);}catch(Exception e){notifyStatus("Cannot connect to "+ip+": "+e.getMessage(),false);}}},"projector-connect").start();
    }

    public synchronized boolean send(String cmd, Map<String,String> fields) {
        try {
            if(writer==null || socket==null || socket.isClosed()) { notifyStatus("Projector not connected",false); return false; }
            writer.write(WireProtocol.build(cmd,fields)); writer.write("\n"); writer.flush(); return true;
        } catch(Exception e){ notifyStatus("Projection connection lost",false); close(); return false; }
    }

    public synchronized void close(){ try{if(writer!=null)writer.close();}catch(Exception ignored){} try{if(socket!=null)socket.close();}catch(Exception ignored){} writer=null;socket=null; }
    private void notifyStatus(String s,boolean c){if(listener!=null)listener.onStatus(s,c);}
}
